<?php
include("header.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" type="text/css" href="style2.css">


    
  </head>
  <style type="text/css">
    #inputbtn:hover{cursor:pointer;}
    .card{
    background: #f8f9fa;
    border-top-left-radius: 5% 5%;
    border-bottom-left-radius: 5% 5%;
    border-top-right-radius: 5% 5%;
    border-bottom-right-radius: 5% 5%;
}

  </style>
  <body style="background: #F0F2F0;background: -webkit-linear-gradient(to bottom, #000C40, #F0F2F0);background: linear-gradient(to bottom, #000C40, #F0F2F0); background-size: cover;">
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav" >
    <div class="container">

      <a class="navbar-brand js-scroll-trigger" href="index.php" style="margin-top: 10px;margin-left:-65px;font-family: 'IBM Plex Sans', sans-serif;"><h4><i class="fa fa-hospital-o" aria-hidden="true"></i>&nbsp HOSPITAL MANAGEMENT SYSTEM</h4></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item" style="margin-right: 40px;">
            <a class="nav-link js-scroll-trigger" href="index.php" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>HOME</h6></a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="contact.html" style="color: white;font-family: 'IBM Plex Sans', sans-serif;"><h6>CONTACT</h6></a>
          </li>
        </ul>
      </div>
    </div>
  </nav>



    <div class="container-fluid" style="margin-top:60px;margin-bottom:60px;color:#34495E;">
      <div class="row">

      <div class="container" style="margin-bottom: 40px; color: black; margin-top: 100px; max-width: 650px;">
    <h2 class="tab-title text-center" style="margin-bottom: 40px; color: black; margin-top: 70px;">Student Sign</h2>
    <form method="post" action="func2.php">
        <div class="row">
            <div class="col-md-4"><label>First Name:</label></div>
            <div class="col-md-8"><input type="text" class="form-control" name="fname" required></div><br><br>
            <div class="col-md-4"><label>Last Name:</label></div>
            <div class="col-md-8"><input type="text" class="form-control" name="lname" required></div><br><br>
            <div class="col-md-4"><label>Gender:</label></div>
            <div class="col-md-8">
                  <label class="radio inline mr-4"> 
                      <input type="radio" name="gender" value="Male" checked>
                      <span> Male </span> 
                  </label>
                  <label class="radio inline ml-4"> 
                      <input type="radio" name="gender" value="Female">
                      <span>Female </span> 
                  </label>
              </div> <br><br>
            <div class="col-md-4"><label>Email ID:</label></div>
            <div class="col-md-8"><input type="email" class="form-control" name="email" required>
            </div><br><br>
            <div class="col-md-4"><label>Contact:</label></div>
            <div class="col-md-8"><input type="number" class="form-control" name="contact"  required>
            </div><br><br>
            <div class="col-md-4"><label>College/University:</label></div>
            <div class="col-md-8"><input type="text" class="form-control" name="college"  required>
            </div><br><br>
            <div class="col-md-4"><label>password:</label></div>
            <div class="col-md-8"><input type="password" class="form-control" name="password" required>
            </div><br><br>
            <div class="col-md-4"><label>Comfirm Password:</label></div>
            <div class="col-md-8"><input type="password" class="form-control" name="cpassword"  required>
            </div><br><br>
            <div class="col-md-12">
                <input type="submit" name="patsub1" value="Sign Up" class="btn btn-block btn-primary">
                <p class="mt-2 text-center">Already have an Account? <a href="login.php">Sign In</a></p>
            </div>
        </div>
    </form>
    </div>

         <!-- <div class="col-md-4" style="margin-top: 5%;right: 8%">
          <div class="card" style="font-family: 'IBM Plex Sans', sans-serif;">
            <div class="card-body">
              <center>
                <br>
                <h3 class="register-heading">Student Register</h3>
                  <form method="post" action="func2.php">
                  <div class="row register-form">
                      
                      <div class="col-md-6">
                          <div class="form-group">
                              <input type="text" class="form-control"  placeholder="First Name *" name="fname" required/>
                          </div>
                          <div class="form-group">
                              <input type="email" class="form-control" placeholder="Your Email *" name="email"  />
                          </div>
                          
                          <div class="form-group">
                              <input type="text" class="form-control"  id="college" placeholder="college/university *" name="college" required/>
                          </div>
                          <div class="form-group">
                              <div class="maxl">
                                  <label class="radio inline"> 
                                      <input type="radio" name="gender" value="Male" checked>
                                      <span> Male </span> 
                                  </label>
                                  <label class="radio inline"> 
                                      <input type="radio" name="gender" value="Female">
                                      <span>Female </span> 
                                  </label>
                              </div>
                              <a href="index1.php">Already have an account? Login Now</a>
                          </div>
                      </div>
                  
                      <div class="col-md-6">
                          <div class="form-group">
                              <input type="text" class="form-control" placeholder="Last Name *" name="lname"  required/>
                          </div>
                          
                          <div class="form-group">
                              <input type="tel" minlength="10" maxlength="10" name="contact" class="form-control" placeholder="Contact *"  />
                          </div>
                          <div class="form-group">
                              <input type="password" class="form-control" placeholder="Password *" id="password" name="password" required/>
                          </div>
                          <div class="form-group">
                              <input type="password" class="form-control"  id="cpassword" placeholder="Confirm Password *" name="cpassword"   required/><span id='message'></span>
                          </div>
                          <input type="submit" class="btnRegister" name="patsub1" value="Register"/>
                      </div>
                  </div>
              </form>
            </center>
            </div>
          </div>
        </div> -->
      </div>
    </div>

    



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
  </body>
</html>